const axios = require('axios');
require('dotenv').config({ path: './.env.github' });

const url = `https://api.github.com/repos/${process.env.GITHUB_REPO}/collaborators/${process.env.GITHUB_USER}`;

axios.put(url, {}, {
  headers: {
    Authorization: `token ${process.env.GITHUB_PAT}`,
    Accept: 'application/vnd.github.v3+json',
  }
}).then(res => {
  console.log("✅ Success:", res.status, res.statusText);
}).catch(err => {
  if (err.response) {
    console.error("❌ Invite failed:");
    console.error("Status:", err.response.status);
    console.error("Message:", err.response.data.message);
  } else {
    console.error("❌ Error:", err.message);
  }
});
