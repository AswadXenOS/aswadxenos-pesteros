#!/data/data/com.termux/files/usr/bin/bash
set -e

echo '🔧 Setup penuh sedang dijalankan...'
npm install

echo '📡 Menjemput AI ke GitHub...'
node invite-github.js || echo '❌ Invite gagal atau telah dijemput.'

echo '🤖 Mengaktifkan Telegram bot...'
npm start
