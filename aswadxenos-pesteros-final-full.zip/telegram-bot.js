const TelegramBot = require('node-telegram-bot-api');
require('dotenv').config();

const bot = new TelegramBot(process.env.TELEGRAM_TOKEN, { polling: true });

bot.onText(/\/start/, (msg) => {
  bot.sendMessage(msg.chat.id, "✅ AswadXenOS SuperAdmin Bot Aktif! Kawalan tersedia.");
});

bot.onText(/\/status/, (msg) => {
  bot.sendMessage(msg.chat.id, "📡 Sistem sedang berjalan sepenuhnya tanpa gangguan.");
});
